# notrack
# Placeholder for the CANJaguar class, which has been removed

__all__ = ["CANJaguar"]

class CANJaguar:

    def __init__(*args, **kwargs):
        raise ValueError("CANJaguar has been removed from wpilib.")

