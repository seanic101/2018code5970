# notrack
# Placeholder for the CANTalon class, which has moved to its own package

__all__ = ["CANTalon"]

class CANTalon:

    def __init__(*args, **kwargs):
        raise ValueError("CANTalon has moved to ctre.CANTalon, you must install robotpy-ctre")

