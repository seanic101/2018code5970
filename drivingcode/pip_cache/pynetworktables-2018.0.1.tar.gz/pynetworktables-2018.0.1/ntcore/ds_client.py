# validated: 0000-00-00 DS 000000000 cpp/DsClient.cpp cpp/DsClient.h
'''----------------------------------------------------------------------------'''
''' Copyright (c) FIRST 2017. All Rights Reserved.                             '''
''' Open Source Software - may be modified and shared by FRC teams. The code   '''
''' must be accompanied by the FIRST BSD license file in the root directory of '''
''' the project.                                                               '''
'''----------------------------------------------------------------------------'''

import logging
logger = logging.getLogger('nt')

class DsClient(object):
    
    def __init__(self, dispatcher, verbose=False):
        pass
    
    def start(self, port):
        logging.warning("Dashboard client mode not currently implemented")
    
    def stop(self):
        pass
